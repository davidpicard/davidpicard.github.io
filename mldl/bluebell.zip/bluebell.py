import csv
import numpy as np
from PIL import Image

class Bluebell():
    def __init__(self, root_dir, mode='train', split = 0):
        self.index = 0
        self.root_dir = root_dir
        self.mode = mode
        split = np.clip(split, 0, 4) if mode != 'test' else 0
        self.split = split

        with open('{}/labels.csv'.format(root_dir), newline='') as f:
            rows = [(img.strip(), cls.strip()) for img, cls in csv.reader(f)]

        begin = split * 300 if mode != 'test' else 0
        n = len(rows)
        keep = np.ones(n, dtype=bool)
        if mode == 'train':
            keep[begin:begin+300] = False
            keep[1500:1800] = False
        elif mode == 'val':
            if begin > 0:
                keep[0:begin] = False
            keep[begin+300:1800] = False
        elif mode == 'test':
            keep[0:1500] = False
        else:
            raise ValueError('invalid mode: "train", "val" or "test" only')

        rows = [row for row, k in zip(rows, keep) if k]

        self.imgs = [img for img, cls in rows]
        classes = [cls for img, cls in rows]
        categories = sorted(set(classes))
        cls_to_id = {cls: i for i, cls in enumerate(categories)}
        self.labels = np.array([cls_to_id[cls] for cls in classes], dtype=int)

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        if idx < 0 or idx >= len(self.imgs):
            raise IndexError
        filename = self.imgs[idx]
        label = self.labels[idx]
        img = Image.open('{}/img/{}'.format(self.root_dir, filename))
        return np.array(img), label
